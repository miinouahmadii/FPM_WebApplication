from flask import Flask, request, jsonify
from flask_restful import Resource, Api, reqparse
from flask_cors import CORS

from core import BasketAnalysis
from utils.utils import draw_network
from error import *

app = Flask(__name__)
CORS(app)
api = Api(app)


model = BasketAnalysis()
rules = None
df = model.load_data()


class basket(Resource):
    def get(self):
        global rules
        global df
        country = request.args["country"]
        df = model.filter_data(country=country)
        rules = model.find_rules()
        # draw_network(rules, "../graph.png")

        # antecedents = list(map(list, rules['antecedents']))
        # consequents = list(map(list, rules['consequents']))
        return jsonify({
            'message': 'Done',
        #     'antecedents': antecedents[:5],
        #     'consequents': consequents[:5]
        })

    def post(self):
        basket = request.get_json().get("basket")
        suggestions = model.suggest_by_basket(basket, rules)
        return jsonify({
            'message': 'Done',
            'suggestions': suggestions
        })
        # raise bad_addressing()

class products(Resource):
    def get(self):
        products = model.get_products()
        return jsonify({
            'message': 'Done',
            'products': products
        })

    def post(self):
        products = request.get_json().get("products")
        customers = model.suggest_by_depot(products, rules)
        return jsonify({
            'message': 'Done',
            'customers': customers
        })

class info(Resource):
    def get(self):
        countries = model.get_countries()
        return jsonify({
            'message': 'Done',
            'countries': countries
        })



# app.register_error_handler(bad_addressing, 403)
# app.register_error_handler(no_rule, 500)

api.add_resource(info, '/info')
api.add_resource(basket, '/basket')
api.add_resource(products, '/products')

if __name__ == '__main__':
    app.run(debug=False)