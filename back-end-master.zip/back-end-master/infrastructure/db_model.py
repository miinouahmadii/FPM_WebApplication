import pandas as pd
from sqlalchemy import create_engine


class Receipts:
    def load_data(self, path = None, excel = True):
        if excel:
            df = pd.read_excel(path)
        else:
            df = pd.read_sql('retail', 'postgresql://fpm:fpm@localhost:5432/fpm_db')
        
        df['Description'] = df['Description'].str.strip()
        return df

    def filter(self, df, country = None):
        if country != None:
            df = df[df['Country'] == country]
        return df

