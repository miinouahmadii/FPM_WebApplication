import pandas as pd
from sqlalchemy import create_engine

df = pd.read_excel('./Online Retail.xlsx')

engine = create_engine('postgresql://fpm:fpm@localhost:5432/fpm_db')

df.to_sql('retail', con=engine)

df2 = pd.read_sql('retail', 'postgresql://fpm:fpm@localhost:5432/fpm_db')

print(df2.head())
