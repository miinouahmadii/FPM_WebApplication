from mlxtend.frequent_patterns import apriori, fpgrowth
from mlxtend.frequent_patterns import association_rules
from itertools import chain, combinations

from error import *

def find_rule(df, algorithm="apriori"):
    if algorithm == "apriori":
        frequent_itemsets = apriori(df, min_support=0.2, use_colnames=True)
    elif algorithm == "fpgrowth":
        frequent_itemsets = fpgrowth(df, min_support=0.2, use_colnames=True)

    rules = association_rules(frequent_itemsets, metric="lift", min_threshold=2)
    best_rules = rules[ (rules['conviction'] >= 4) & (rules['confidence'] >= 0.8) ]
    return best_rules
    # return rules

