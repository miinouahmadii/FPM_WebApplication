from itertools import chain, combinations
import numpy as np
import warnings
warnings.filterwarnings('ignore')

from infrastructure.db_model import Receipts
from utils.utils import binary_onehot_encoding
from domain.asc_rule import find_rule
from error import *

class BasketAnalysis():
    receipts = Receipts()

    def load_data(self):
        # self.main_df = self.receipts.load_data(path='./Online Retail.xlsx')
        self.main_df = self.receipts.load_data(excel=False)
        return self.main_df

    def filter_data(self, country = None):
        # should move to db_model
        temp_df = self.receipts.filter(self.main_df, country)
        self.df = temp_df[['CustomerID', 'Description']]
        return self.df

    def get_countries(self):
        countries = np.unique(self.main_df['Country'].tolist())
        return list(countries)

    def get_products(self):
        products = np.unique(self.df['Description'].tolist())
        return list(products)

    def get_rules(self, product: list, rules):
        idx = []
        idx += list(rules[rules['antecedents'] == set(product)].index.values)
        rules = rules.loc[idx]
        return list(rules)

    def find_rules(self):
        onehot_df = binary_onehot_encoding(self.df)
        # best_rules = find_rule(onehot_df)
        best_rules = find_rule(onehot_df, algorithm="fpgrowth")
        print(len(best_rules))
        if len(best_rules) == 0:
            raise no_rule()
        best_rules.reset_index(drop=True, inplace=True)
        return best_rules

    def suggest_by_basket(self, basket: list, rules, le = 2):
        basket = np.array(basket)
        basket = list(chain.from_iterable(combinations(basket, r+1) for r in range(le)))
        idx = []
        drop_idx = []

        for i in range(len(basket)):
            idx += list(rules[rules['antecedents'] == set(basket[i])].index.values)

        for i in idx:
            if tuple(rules.loc[i, 'consequents']) in basket:
                drop_idx.append(i)

        idx = np.setdiff1d(idx, drop_idx)
        rules = rules.loc[idx]
        suggest = list(map(list, rules['consequents']))
        if len(suggest) == 0:
            raise no_suggestion()
        suggest = np.unique(list(np.concatenate(suggest).flat))

        return list(suggest)

    def suggest_by_depot(self, products: list, rules):
        idx = []
        idx += list(rules[rules['consequents'] == set(products)].index.values)

        new_rules = rules.loc[idx]

        suggest2 = list(map(list, new_rules['antecedents']))
        if len(suggest2)==0:
            raise no_suggestion()
        suggest2 = np.unique(list(np.concatenate(suggest2).flat))

        suggest_customer = np.unique(self.main_df[self.main_df['Description'].isin(suggest2)]['CustomerID'].tolist())
        
        suggest_customer = suggest_customer[~np.isnan(suggest_customer)]
        return list(suggest_customer)


