import werkzeug


class bad_addressing(werkzeug.exceptions.HTTPException):
    code = 403
    description = 'The location not found!'

class no_rule(werkzeug.exceptions.HTTPException):
    code = 500
    description = 'No rules found!'

class no_suggestion(werkzeug.exceptions.HTTPException):
    code = 500
    description = 'No suggestion found!'