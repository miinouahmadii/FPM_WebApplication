import networkx as nx
import matplotlib.pyplot as plt
import pandas as pd

# from mlxtend.preprocessing import TransactionEncoder


def binary_onehot_encoding(df: pd.DataFrame):
    enc = pd.get_dummies(df.Description).join(df['CustomerID'])
    enc = enc.groupby(['CustomerID']).sum()
    enc[enc>1] = 1
    # te = TransactionEncoder()
    # te_ary = te.fit(df['Description']).transform(df['CustomerID'])
    # enc = pd.DataFrame(te_ary, columns=te.columns_)
    return enc

def draw_network(rules: pd.DataFrame, path):
    f = plt.figure(figsize=(16, 12))
    G=nx.from_pandas_edgelist(rules, 'antecedents', 'consequents', create_using=nx.DiGraph())
    nx.draw(G, with_labels=False, node_size=50, alpha=0.3, arrows=True, ax=f.add_subplot(111))
    f.savefig(path)

