# Back-end

## First create a venv:

```
python3 -m venv venv
. venv/bin/activate
```

## Install the requirments using:

```
pip3 install -r requirments.txt
```

## Run the app using:

```
python3 main.py
```