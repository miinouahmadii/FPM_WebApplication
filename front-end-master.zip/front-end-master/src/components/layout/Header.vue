<template>
  <header>
    <nav class="navbar navbar-expand-lg navbar-light ">
      <div class="container-fluid">
        <!-- <a class="navbar-brand" href="#">Basket Analysis</a> -->

        <div class="logo-cover">
          <div>
            <img src="../../assets/ut-logo.png" />
          </div>

          <div class="logo-text pcb-text">
            <strong class="text-white"> Basket Analysis </strong><br />
            <small class="text-white">School Of Engineering Science</small>
            <!-- <img src="../../assets/engsci-logo.png" /> -->
          </div>
        </div>

        <!-- <div class="text-center">
          <p class="pcb-text">
            <router-link :to="{ name: 'home' }" class="navbar-brand">
              Basket Analysis
            </router-link>
          </p>
        </div> -->

        &nbsp;&nbsp;&nbsp;

        <button
          class="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav me-auto mb-2 mb-lg-0">
            <!-- <li class="nav-item">
              <router-link :to="{ name: 'home' }" class="nav-link">
                Home
              </router-link>
            </li> -->

            <li class="nav-item">
              <router-link :to="{ name: 'rules' }" class="nav-link">
                Rules
              </router-link>
            </li>

            <li class="nav-item">
              <router-link :to="{ name: 'market' }" class="nav-link">
                Market
              </router-link>
            </li>

            <li class="nav-item">
              <router-link :to="{ name: 'contact' }" class="nav-link">
                Contact
              </router-link>
            </li>

            <li class="nav-item">
              <router-link :to="{ name: 'about' }" class="nav-link">
                About
              </router-link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  </header>
</template>

<script>
export default {
  name: "Header",
  setup() {},
};
</script>

<style scoped>
.router-link-active {
  color: blue;
}

.pcb-text strong {
  /* font-size: 60px; */
  animation: typing 4s forwards infinite;
  overflow: hidden;
  white-space: nowrap;
  margin: 0 auto;
  color: white;
  /* border-right: 0.1em solid orange; */
}

@keyframes typing {
  from {
    width: 0;
  }
  to {
    width: 100%;
  }
}

.logo-cover > div {
  display: inline-block;
}

.logo-text {
  margin: 0;
  position: absolute;
  top: 50%;
  -ms-transform: translateY(-50%);
  transform: translateY(-50%);
}

.navbar-collapse {
  margin-left: 200px;
}

.navbar {
  background-color: #716f81;
}

.navbar-light .navbar-brand {
  color: white;
}

.navbar-light .navbar-nav .nav-link {
  color: white;
}
</style>
