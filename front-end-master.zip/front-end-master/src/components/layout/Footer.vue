<template>
  <footer>
    <div class="container-fluid scroll">
      <div class="row">
        <p class="text-white text-center">
          All Right Reserved
        </p>
      </div>
    </div>
  </footer>
</template>

<script>

export default {
  name: "Footer",
  setup() {
    return { title: "Footer" };
  },
};
</script>


<style scoped>

footer {
  position: fixed;
  height: 50px;
  bottom: 0;
  width: 100%;
  background-color: #959497;
}

.row p {
  padding-top: 10px;
}
</style>
