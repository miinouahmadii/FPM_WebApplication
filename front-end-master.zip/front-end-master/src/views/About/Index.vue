<template>
  <div class="container mt-4">
    <div class="row">
      <div class="col-md-12">
        <div class="text-center left">
          <div>
            <img
              src="../../assets/teacher.jpg"
              class="img-responsive"
              title="DR.Ali Fahim Supervisor"
              alt="DR.Ali Fahim Supervisor"
            />
          </div>

          <div class="text-center title">
            <strong>DR.Ali Fahim</strong> <br />
            <strong>Supervisor</strong> <br />
            <strong> A.fahim@ut.ac.ir</strong>
          </div>
        </div>
        <hr />
        <div class="text-center">
          <div>
            <img
              src="../../assets/frontdev.jpg"
              class="img-responsive"
              title="Minoo Ahmadi Researcher and front-end developer"
              alt="Minoo Ahmadi Researcher and front-end developer"
            />
          </div>

          <div class="text-center title">
            <strong> Minoo Ahmadi</strong> <br />
            <strong>Researcher And front-end developer</strong> <br />
            <strong>minoo.ahmadi@ut.ac.ir</strong>
          </div>
        </div>

        <hr />
        <div class="text-center mb-20">
          <div>
            <img
              src="../../assets/backdev.jpg"
              class="img-responsive"
              title="Aref Afzali Researcher and back-end developer"
              alt="Aref Afzali Researcher and back-end developer"
            />
          </div>

          <div class="text-center title">
            <strong> Aref Afzali</strong> <br />
            <strong>Researcher And back-end developer</strong> <br />
            <strong>Afzaliaref.aa@gmail.com</strong>
          </div>
        </div>

        <hr />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "AboutIndex",
  data() {
    return {
      title: "About",
    };
  },
  mounted() {},
  methods: {},
};
</script>

<style scoped>
img {
  width: 150px;
  height: 150px;
  border-radius: 30px;
  margin-top: 8px;
  box-shadow: 5px 5px #e0e0e0;
}

.card {
  box-shadow: 5px 8px #e9d7d7;
  border-radius: 10px;
  padding: 10px;
  margin-top: 16px;
}

.title {
  font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
  margin-top: 8px;
}
</style>
