<template>
  <div class="container mt-4">
    <div class="row">
      <div>
        <strong>
          Select your Country
        </strong>
        <br /><br />

        <select class="form-control dropdown-toggle" v-model="selected">
          <optgroup label="Select Country ... ">
            <option v-for="value in countries" :key="value">
              {{ value }}
            </option>
          </optgroup>
        </select>

        <br />

        <button @click="getRules" class="btn btn-success" :disabled="!selected">
          Get Rules
        </button>

        <br />
        <br />

        <span v-if="selected"> Selected Country Is : {{ selected }}</span>

        <br />
        <br />

        <div v-if="loading" class="spinner-border mt-4" role="status">
          <span class="visually-hidden">Loading...</span>
        </div>

        <br />

        <span v-if="message"> Result : {{ message }}</span>

        <br />
        <br />

        <img
          v-if="path"
          class="img-thumbnail m-auto"
          :src="path"
          alt="Rules Network Graph"
        />
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "RuleIndex",
  // setup() {
  //   let title = "Rule Page";
  //   return { title };
  // },
  data() {
    return {
      message: "",
      selected: "",
      countries: null,
      loading: false,
      path: "",
    };
  },
  mounted() {
    axios
      .get("http://localhost:5000/info")
      .then((response) => {
        this.countries = response.data.countries;
      })
      .catch((error) => {
        alert("Error  " + error.message);
      });
  },
  methods: {
    getRules() {
      this.loading = true;
      this.message = "";
      this.path = "";
      // this.message = "Processing...";
      axios
        .get("http://localhost:5000/basket", {
          params: { country: this.selected },
        })
        .then((response) => {
          console.log(response);
          this.loading = false;
          this.message = response.data.message;
          this.path = response.data.path;
        })
        .catch((error) => {
          this.loading = false;
          alert("Error  " + error.message);
        });

     
    },
  },
};
</script>

<style scoped></style>
