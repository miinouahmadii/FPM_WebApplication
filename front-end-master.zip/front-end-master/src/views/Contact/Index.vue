<template>
  <div class="container mt-4">
    <div class="row">
      <div class="col-md-6">
        <div class="form-group">
          <input
            type="text"
            class="form-control"
            name="name"
            id="name"
            placeholder="Name"
          />
        </div>

        <div class="form-group">
          <input
            type="text"
            class="form-control"
            name="email"
            id="email"
            placeholder="Email"
          />
        </div>

        <div class="form-group">
          <textarea
            class="form-control"
            name="message"
            id="message"
            placeholder="Message"
          />
        </div>

        <div class="form-group">
          <button class="btn btn-success" id="btn-send">Send</button>
        </div>
      </div>

      <div class="col-md-6">
        <div>
          <img
            src="../../assets/address.jpg"
            class="img-thumbnail img-responsive"
          />
        </div>

        <!-- <div>
          <div>
            <span class="glyphicon glyphicon-asterisk"></span>
          </div>

          <div>
            <span class="glyphicon glyphicon-asterisk"></span>
          </div>

          <div>
            <span class="glyphicon glyphicon-asterisk"></span>
          </div>
        </div> -->
        
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "ContactIndex",
  data() {
    return {
      title: "Contact",
    };
  },
  mounted() {},
  methods: {},
};
</script>

<style>
.form-group {
  margin-top: 8px;
}

textarea {
  max-height: 200px;
  max-width: auto;
}
</style>
