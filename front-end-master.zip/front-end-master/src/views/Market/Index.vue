<template>
  <div class="container mt-4">
    <div class="row">
      <div class="col-md-4">
        <div>
          <br />

          <strong>Select Your Products</strong>

          <br />
          <br />

          <!-- <select>
            <option v-for="item in products" :key="item">
              {{ item }}
            </option>
          </select> -->

          <select
            class="form-control dropdown-toggle"
            @change="onChange($event)"
          >
            <optgroup label="Select Product ... ">
              <option v-for="item in products" :key="item">
                {{ item }}
              </option>
            </optgroup>
          </select>
        </div>

        <div v-if="selected.length != 0">
          <br />
          <br />

          <strong>Basket</strong>

          <br />
          <br />

          <ul class="list-group" style="margin-right:16px">
            <li
              class="list-group-item mt-2"
              v-for="product in selected"
              :key="product"
            >
              {{ product }}
              <span class="close" v-on:click="deleteItem(product)"
                >&times;</span
              >
            </li>
          </ul>
        </div>
      </div>

      <div class="col-md-4">
        <div>
          <br />

          <strong>Suggestions</strong>

          <br />
          <br />

          <button
            :disabled="selected.length == 0"
            class="btn"
            @click="getSuggestions"
          >
            Get Suggestions
          </button>

          <br />
          <br />

          <div v-if="loading" class="spinner-border mt-4" role="status">
            <span class="visually-hidden">Loading...</span>
          </div>

          <ul class="list-group">
            <li
              class="list-group-item mt-2"
              v-for="value in suggestions"
              :key="value"
            >
              {{ value }}
            </li>
          </ul>
        </div>
      </div>

      <div class="col-md-4">
        <div>
          <br />

          <strong>Customers</strong>

          <br />
          <br />

          <button
            :disabled="selected.length == 0"
            class="btn"
            @click="getCustomers"
          >
            Get Customers
          </button>

          <br />
          <br />

          <ul class="list-group">
            <li
              class="list-group-item mt-2"
              v-for="value in customers"
              :key="value"
            >
              {{ value }}
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
export default {
  name: "MarketIndex",
  // setup() {
  //   let title = "Market Page";
  //   return { title };
  // },

  data() {
    return {
      selected: [],
      products: null,
      suggestions: null,
      customers: null,
      loading: false,
    };
  },
  mounted() {
    axios
      .get("http://localhost:5000/products")
      .then((response) => {
        this.products = response.data.products;
      })
      .catch((error) => {
        console.log(error);
        this.errored = true;
      });
  },
  methods: {
    getCustomers() {
      axios
        .post("http://localhost:5000/products", {
          products: this.selected,
        })
        .then((response) => {
          this.customers = response.data.customers;
        })
        .catch((error) => {
          alert("Error " + error.message);
          console.log(error);
        });
    },
    getSuggestions() {
      this.loading = true;
      axios
        .post("http://localhost:5000/basket", {
          basket: this.selected,
        })
        .then((response) => {
          console.log(response);
          this.suggestions = response.data.suggestions;
          this.loading = false;
        })
        .catch((error) => {
          alert("Error " + error.message);
          console.log(error);
          this.loading = false;
        });
    },

    deleteItem(product) {
      this.selected.splice(this.selected.indexOf(product), 1);
    },

    onChange(event) {
      this.selected.push(event.target.value);
    },
  },
};
</script>

<style scoped>
.close {
  cursor: pointer;
  float: right;
  color: red;
}

button {
  background-color: #b97a95;
}
</style>
