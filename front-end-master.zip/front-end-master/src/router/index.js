import { createRouter, createWebHistory } from "vue-router";

// import Home from "../views/Home.vue";
import RuleIndex from "../views/Rule/Index.vue";
import MarketIndex from "../views/Market/Index.vue";
import ContactIndex from "../views/Contact/Index.vue";
import AboutIndex from "../views/About/Index.vue";

const routes = [
  // { path: "/", name: "home", component: Home },
  { path: "/rules", name: "rules", component: RuleIndex },
  { path: "/market", name: "market", component: MarketIndex },
  { path: "/contact", name: "contact", component: ContactIndex },
  { path: "/about", name: "about", component: AboutIndex },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
